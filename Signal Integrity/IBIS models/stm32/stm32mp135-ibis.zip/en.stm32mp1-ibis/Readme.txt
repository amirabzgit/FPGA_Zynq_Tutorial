****************************************************************************************
* @file     readme.txt                                                              
* @author   MCD Application Team                                                    
* @version  V2.0                                                                    
* @date     06-March-2024
* @brief    I/O Buffer Information Specification (IBIS) files for the STM32MP1 devices.    
****************************************************************************************
* COPYRIGHT(c) 2024 STMicroelectronics                                             
*                                                                                  
* Redistribution and use in source and binary forms, with or without modification, 
* are permitted provided that the following conditions are met:                    
*   1. Redistributions of source code must retain the above copyright notice,      
*      this list of conditions and the following disclaimer.                       
*   2. Redistributions in binary form must reproduce the above copyright notice,   
*      this list of conditions and the following disclaimer in the documentation  
*      and/or other materials provided with the distribution.                      
*   3. Neither the name of STMicroelectronics nor the names of its contributors    
*      may be used to endorse or promote products derived from this software       
*      without specific prior written permission.                                  
*                                                                                  
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"      
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE        
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE   
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE     
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL       
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR       
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER       
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,    
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE    
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.             
****************************************************************************************


================================
IBIS files for STM32MP1 devices:
================================

The package contains :


   + IBIS Files for STM32MP131_133_135 devices on different packages :  

	  o LFBGA289
	  o TFBGA289
          o TFBGA320


========================
* V2.0 - 06-March-2024 
========================
    + Updated the IBIS files for STM32MP131_133_135 devices:

       -Remove the comments for diff pin

       -Add receiver thresholds for MSD_D3RP3L_34
       -Add receiver thresholds for MSD_D3RP3L_40
       -Add receiver thresholds for MSD_D3RP3L_48
       -Add receiver thresholds for MSD_D3RP3L_ODT120
       -Add receiver thresholds for MSD_D3RP3L_ODT40
       -Add receiver thresholds for MSD_D3RP3L_ODT60
       -Add receiver thresholds for MSD_D3RP3L_ODTOFF

       -Add receiver thresholds for MSD_D3RF3L_34_X
       -Add receiver thresholds for MSD_D3RF3L_40_X
       -Add receiver thresholds for MSD_D3RF3L_48_X
       -Add receiver thresholds for MSD_D3RF3L_ODT120_X
       -Add receiver thresholds for MSD_D3RF3L_ODT40_X
       -Add receiver thresholds for MSD_D3RF3L_ODT60_X
  
       -Add receiver thresholds for MSD_D3RPL2_34
       -Add receiver thresholds for MSD_D3RPL2_40
       -Add receiver thresholds for MSD_D3RP3L_48
       -Add receiver thresholds for MSD_D3RPL2_60
       -Add receiver thresholds for MSD_D3RPL2_80

       -Add receiver thresholds for MSD_D3RFL2_34_X
       -Add receiver thresholds for MSD_D3RFL2_40_X
       -Add receiver thresholds for MSD_D3RFL2_48_X
       -Add receiver thresholds for MSD_D3RFL2_60_X
       -Add receiver thresholds for MSD_D3RFL2_80_X
========================
* V1.0 - 03-August-2022 
========================
    + Created with IBIS files for STM32MP131_133_135 devices.

******************* (C) COPYRIGHT 2024 STMicroelectronics *****END OF FILE