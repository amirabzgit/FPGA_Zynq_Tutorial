V00H IBIS Model
Die Rev P
8Gb TwinDie DDR3 SDRAM IBIS models
EBD package models, Rev 1.0, 05/07/2018
DRAM Die model (1.5V), v00h.ibs, Rev 2.0, 08/25/2015
DRAM Die model (1.35V), v00h_1p35.ibs, Rev 2.1, 08/25/2015

The TwinDie packages are modeled using the IBIS EBD syntax.  2 package models are
included as detailed below:

v00hx4_2cob_ddp.ebd - 4Gbx4 TwinDie 1.5V - MT41K2G4RKB:P
v00hx8_2cob_ddp.ebd - 2Gbx8 TwinDie 1.5V - MT41K1G8RKB:P
v00hx4_1p35v_2cob_ddp.ebd - 4Gbx4 TwinDie 1.35V - MT41K2G4RKB:P
v00hx8_1p35v_2cob_ddp.ebd - 2Gbx8 TwinDie 1.53V - MT41K1G8RKB:P

The die are modeled with the v00h.ibs model for 1.5V.
The die are modeled with the v00h_1p35.ibs model for 1.35V.


The v00h.ibs model includes On Die Termination (ODT) characteristics.  ODT in DQ* 
models are modeled through the use of [Submodel] power and ground clamp I-V curves 
that add the termination characteristics to the regular power and ground clamp
characteristics when the I/O is functioning as an input. Use the [Model Selector] 
to choose between 20,30,40,60 and 120 ohm ODT settings.

NOTE: C_comp is different for the ODT-enabled models versus the normal I/O model.
The C_comp value is set to match the input state of the DQ I/O as measured from
the HSPICE model.  Due to the C_comp differences between the DQ model and the
DQ_ODT* models, the output characteristics of the models will look different
when simulated.  So, to match most closely with the HSPICE model, simulate with
the DQ_34/40_1066/1600 models for ALL Output simulations.  Use the ODT models
ONLY for Input simulations. 

[Disclaimer]    This software code and all associated documentation, comments
                or other information (collectively "Software") is provided 
                "AS IS" without warranty of any kind. MICRON TECHNOLOGY, INC. 
                ("MTI") EXPRESSLY DISCLAIMS ALL WARRANTIES EXPRESS OR IMPLIED,
                INCLUDING BUT NOT LIMITED TO, NONINFRINGEMENT OF THIRD PARTY
                RIGHTS, AND ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS
                FOR ANY PARTICULAR PURPOSE. MTI DOES NOT WARRANT THAT THE
                SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE OPERATION OF
                THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE. FURTHERMORE,
                MTI DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE
                RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS,
                ACCURACY, RELIABILITY, OR OTHERWISE. THE ENTIRE RISK ARISING OUT
                OF USE OR PERFORMANCE OF THE SOFTWARE REMAINS WITH YOU. IN NO
                EVENT SHALL MTI, ITS AFFILIATED COMPANIES OR THEIR SUPPLIERS BE
                LIABLE FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR
                SPECIAL DAMAGES (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS
                OF PROFITS, BUSINESS INTERRUPTION, OR LOSS OF INFORMATION)
                ARISING OUT OF YOUR USE OF OR INABILITY TO USE THE SOFTWARE,
                EVEN IF MTI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
                Because some jurisdictions prohibit the exclusion or limitation
                of liability for consequential or incidental damages, the above
                limitation may not apply to you.
 
                Copyright 2018 Micron Technology, Inc. All rights reserved.
